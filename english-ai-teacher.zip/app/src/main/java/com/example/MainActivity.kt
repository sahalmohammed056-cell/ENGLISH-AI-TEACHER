package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.local.AppDatabase
import com.example.data.repository.AppRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.AndroidTextToSpeech
import com.example.viewmodel.*

class MainActivity : ComponentActivity() {
    private lateinit var tts: AndroidTextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize local SQLite Database & Repository
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = AppRepository(
            lessonDao = database.lessonProgressDao(),
            vocabDao = database.vocabProgressDao(),
            quizDao = database.quizScoreDao(),
            statsDao = database.userStatsDao()
        )

        // 2. Initialize our ViewModel Architecture
        val mainViewModel = ViewModelProvider(
            this,
            MainViewModelFactory(application, repository)
        )[MainViewModel::class.java]

        val chatViewModel = ViewModelProvider(
            this,
            ChatViewModelFactory(application)
        )[ChatViewModel::class.java]

        val pronunciationViewModel = ViewModelProvider(
            this,
            PronunciationViewModelFactory(application)
        )[PronunciationViewModel::class.java]

        // 3. Initialize TextToSpeech engine in Activity scope
        tts = AndroidTextToSpeech(applicationContext)

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "dashboard",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("dashboard") {
                            DashboardScreen(
                                mainViewModel = mainViewModel,
                                onNavigateToChat = { navController.navigate("chat") },
                                onNavigateToLessons = { navController.navigate("lessons") },
                                onNavigateToVocab = { navController.navigate("vocab") },
                                onNavigateToPronunciation = { navController.navigate("pronunciation") },
                                onNavigateToQuizzes = { navController.navigate("quizzes") }
                            )
                        }

                        composable("chat") {
                            ChatScreen(
                                mainViewModel = mainViewModel,
                                chatViewModel = chatViewModel,
                                tts = tts,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("lessons") {
                            LessonsScreen(
                                mainViewModel = mainViewModel,
                                tts = tts,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("vocab") {
                            VocabScreen(
                                mainViewModel = mainViewModel,
                                tts = tts,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("pronunciation") {
                            PronunciationScreen(
                                mainViewModel = mainViewModel,
                                pronunciationViewModel = pronunciationViewModel,
                                tts = tts,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("quizzes") {
                            QuizScreen(
                                mainViewModel = mainViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::tts.isInitialized) {
            tts.shutdown()
        }
    }
}
