package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.api.Content
import com.example.api.Part
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        // Welcome message
        _messages.value = listOf(
            ChatMessage(
                text = "ഹലോ! ഞാൻ നിങ്ങളുടെ English AI Teacher ആണ്. നമുക്ക് ഒരുമിച്ച് ഇംഗ്ലീഷ് പഠിക്കാം. ഇംഗ്ലീഷിലോ മലയാളത്തിലോ എന്നോട് ചോദിക്കാം. (Hello! I am your English AI Teacher. Let's learn English together. You can ask me in English or Malayalam.)",
                isUser = false
            )
        )
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        // Add user message
        val userMsg = ChatMessage(text = userText, isUser = true)
        _messages.value = _messages.value + userMsg
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            // Build historical prompt with conversation context
            val builder = StringBuilder()
            builder.append("You are English AI Teacher. Here is the conversation history with the student so far:\n\n")
            
            // Limit history to last 10 messages for token context efficiency
            val historyLimit = _messages.value.takeLast(10)
            for (msg in historyLimit) {
                if (msg.isUser) {
                    builder.append("Student: ${msg.text}\n")
                } else {
                    builder.append("English AI Teacher: ${msg.text}\n")
                }
            }
            builder.append("\nRespond to the last Student message warmly and in accordance with your guidelines (explaining in Malayalam when appropriate).")

            val prompt = builder.toString()
            
            // Execute Gemini call
            val result = GeminiClient.chatWithTeacher(emptyList(), prompt)
            
            _isLoading.value = false
            result.onSuccess { reply ->
                _messages.value = _messages.value + ChatMessage(text = reply, isUser = false)
            }.onFailure { exception ->
                val offlineReply = "ക്ഷമിക്കണം, എനിക്ക് ഇപ്പോൾ ഓൺലൈൻ സേവനവുമായി ബന്ധപ്പെടാൻ സാധിക്കുന്നില്ല. (Sorry, I cannot connect to the online AI service right now. Please check your internet connection or configure your API Key.)\n\nമാതൃക ചോദ്യങ്ങൾ ചോദിക്കാൻ താഴെയുള്ള ബട്ടണുകൾ ഉപയോഗിക്കുക!"
                _messages.value = _messages.value + ChatMessage(text = offlineReply, isUser = false)
                _error.value = exception.message
            }
        }
    }

    fun clearChat() {
        _messages.value = listOf(
            ChatMessage(
                text = "ഹലോ! വീണ്ടും സ്വാഗതം. ഞാൻ നിങ്ങളുടെ English AI Teacher ആണ്. എന്ത് സഹായമാണ് ഇന്ന് വേണ്ടത്? (Hello! Welcome back. I am your English AI Teacher. How can I help you today?)",
                isUser = false
            )
        )
    }
}

class ChatViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChatViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ChatViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
