package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.model.Lesson
import com.example.data.model.LessonProgress
import com.example.data.model.Quiz
import com.example.data.model.QuizScore
import com.example.data.model.StaticData
import com.example.data.model.UserStats
import com.example.data.model.VocabProgress
import com.example.data.model.Vocabulary
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainViewModel(
    application: Application,
    private val repository: AppRepository
) : AndroidViewModel(application) {

    val lessonProgress: StateFlow<List<LessonProgress>> = repository.allLessonProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val vocabProgress: StateFlow<List<VocabProgress>> = repository.allVocabProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quizScores: StateFlow<List<QuizScore>> = repository.allQuizScores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userStats: StateFlow<UserStats?> = repository.userStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            repository.updateStreakAndActivity()
        }
    }

    fun isAiAvailable(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
    }

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Calendar.getInstance().time)
    }

    // --- Dynamic Daily Challenge ---
    fun isDailyChallengeCompleted(): Boolean {
        val stats = userStats.value ?: return false
        val today = getTodayDateString()
        return stats.lastChallengeDate == today
    }

    fun completeLesson(lessonId: String) {
        viewModelScope.launch {
            repository.completeLesson(lessonId)
        }
    }

    fun practiceVocab(vocabId: String, markAsMastered: Boolean) {
        viewModelScope.launch {
            repository.practiceVocab(vocabId, markAsMastered)
        }
    }

    fun saveQuizScore(quizId: String, score: Int, total: Int) {
        viewModelScope.launch {
            repository.saveQuizScore(quizId, score, total)
        }
    }

    fun completeDailyChallenge() {
        viewModelScope.launch {
            repository.completeDailyChallenge()
        }
    }

    fun earnPronunciationXp() {
        viewModelScope.launch {
            repository.earnPronunciationXp()
        }
    }
}

class MainViewModelFactory(
    private val application: Application,
    private val repository: AppRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
