package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.data.model.StaticData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PronunciationViewModel(application: Application) : AndroidViewModel(application) {

    private val sentences = StaticData.pronunciationSentences
    private var currentIndex = 0

    private val _targetSentence = MutableStateFlow(sentences[0])
    val targetSentence: StateFlow<String> = _targetSentence

    private val _userSpeechResult = MutableStateFlow("")
    val userSpeechResult: StateFlow<String> = _userSpeechResult

    private val _evaluationFeedback = MutableStateFlow<String?>(null)
    val evaluationFeedback: StateFlow<String?> = _evaluationFeedback

    private val _isEvaluating = MutableStateFlow(false)
    val isEvaluating: StateFlow<Boolean> = _isEvaluating

    private val _isOfflineEvaluation = MutableStateFlow(false)
    val isOfflineEvaluation: StateFlow<Boolean> = _isOfflineEvaluation

    fun nextSentence() {
        currentIndex = (currentIndex + 1) % sentences.size
        _targetSentence.value = sentences[currentIndex]
        _userSpeechResult.value = ""
        _evaluationFeedback.value = null
        _isOfflineEvaluation.value = false
    }

    fun setSpeechResultAndEvaluate(speechText: String, onXpEarned: () -> Unit) {
        if (speechText.isBlank()) return
        _userSpeechResult.value = speechText
        _isEvaluating.value = true
        _evaluationFeedback.value = null
        _isOfflineEvaluation.value = false

        viewModelScope.launch {
            // Try online evaluation
            val result = GeminiClient.getPronunciationFeedback(_targetSentence.value, speechText)
            _isEvaluating.value = false
            
            result.onSuccess { feedback ->
                _evaluationFeedback.value = feedback
                onXpEarned()
            }.onFailure {
                // Offline fallback evaluation
                _isOfflineEvaluation.value = true
                val feedback = evaluateOffline(_targetSentence.value, speechText)
                _evaluationFeedback.value = feedback
                onXpEarned() // Still give XP for trying offline!
            }
        }
    }

    /**
     * Helper to perform a smart text comparison offline and provide Malayalam feedback.
     */
    private fun evaluateOffline(target: String, userText: String): String {
        val cleanTarget = target.lowercase().replace(Regex("[^a-z0-9\\s]"), "")
        val cleanUser = userText.lowercase().replace(Regex("[^a-z0-9\\s]"), "")

        val targetWords = cleanTarget.split("\\s+".toRegex()).filter { it.isNotEmpty() }
        val userWords = cleanUser.split("\\s+".toRegex()).filter { it.isNotEmpty() }

        if (targetWords.isEmpty()) return "ശ്രമിച്ചതിന് നന്ദി! വീണ്ടും ശ്രമിക്കുക."

        var matches = 0
        for (word in userWords) {
            if (targetWords.contains(word)) {
                matches++
            }
        }

        val accuracy = matches.toFloat() / targetWords.size
        val stars = when {
            accuracy >= 0.9f -> "⭐⭐⭐⭐⭐"
            accuracy >= 0.7f -> "⭐⭐⭐⭐"
            accuracy >= 0.4f -> "⭐⭐⭐"
            accuracy >= 0.1f -> "⭐⭐"
            else -> "⭐"
        }

        val explanation = when {
            accuracy >= 0.9f -> "മികച്ച ശ്രമം! നിങ്ങൾ എല്ലാ വാക്കുകളും കൃത്യമായി ഉച്ചരിച്ചു. (Excellent try! You pronounced the words perfectly.)"
            accuracy >= 0.7f -> "വളരെ നല്ല ശ്രമം! കുറച്ചുകൂടി ശ്രദ്ധിച്ചാൽ ഇതിലും നന്നായി പറയാം. (Very good attempt! A bit more focus and you will get it perfect.)"
            accuracy >= 0.4f -> "നല്ല ശ്രമം! ചില വാക്കുകൾ വിട്ടുപോയിട്ടുണ്ട്. വീണ്ടും പരിശീലിക്കുക. (Good attempt! Some words were missed, please practice again.)"
            else -> "കുറച്ചുകൂടി ഉച്ചത്തിൽ വ്യക്തമായി സംസാരിക്കാൻ ശ്രമിക്കുക. (Please try to speak a bit louder and more clearly.)"
        }

        return "📱 [ഓഫ്‌ലൈൻ വിലയിരുത്തൽ (Offline Evaluator)]\n\n" +
                "താങ്കളുടെ സ്കോർ: $stars\n\n" +
                "$explanation\n\n" +
                "നിങ്ങൾ പറഞ്ഞത്: \"$userText\"\n\n" +
                "ലക്ഷ്യം: \"$target\""
    }
}

class PronunciationViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PronunciationViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PronunciationViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
