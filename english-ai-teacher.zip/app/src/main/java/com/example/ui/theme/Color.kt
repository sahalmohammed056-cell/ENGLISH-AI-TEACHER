package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Professional Polish Theme Colors ---
val ProfPrimary = Color(0xFF6750A4)
val ProfOnPrimary = Color(0xFFFFFFFF)
val ProfPrimaryContainer = Color(0xFFD3E3FD)
val ProfOnPrimaryContainer = Color(0xFF001D35)

val ProfSecondary = Color(0xFF0B57D0)
val ProfOnSecondary = Color(0xFFFFFFFF)
val ProfSecondaryContainer = Color(0xFFE8DEF8)
val ProfOnSecondaryContainer = Color(0xFF21005D)

val ProfBackground = Color(0xFFF3F4F9)
val ProfOnBackground = Color(0xFF1D1B20)

val ProfSurface = Color(0xFFFFFFFF)
val ProfOnSurface = Color(0xFF1D1B20)

val ProfSurfaceVariant = Color(0xFFF1F2F6)
val ProfOnSurfaceVariant = Color(0xFF49454F)

val ProfOutline = Color(0xFFE2E8F0) // slate-200
val AccentIndigo = Color(0xFFEADDFF)
val AccentRed = Color(0xFFF2B8B5)
val AccentRedText = Color(0xFF601410)
