package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val ProfessionalColorScheme = lightColorScheme(
    primary = ProfPrimary,
    onPrimary = ProfOnPrimary,
    primaryContainer = ProfPrimaryContainer,
    onPrimaryContainer = ProfOnPrimaryContainer,
    secondary = ProfSecondary,
    onSecondary = ProfOnSecondary,
    secondaryContainer = ProfSecondaryContainer,
    onSecondaryContainer = ProfOnSecondaryContainer,
    background = ProfBackground,
    onBackground = ProfOnBackground,
    surface = ProfSurface,
    onSurface = ProfOnSurface,
    surfaceVariant = ProfSurfaceVariant,
    onSurfaceVariant = ProfOnSurfaceVariant,
    outline = ProfOutline
)

// A dark variant that matches the professional aesthetic but is darker
private val ProfessionalDarkColorScheme = darkColorScheme(
    primary = ProfPrimary,
    onPrimary = ProfOnPrimary,
    primaryContainer = ProfPrimaryContainer,
    onPrimaryContainer = ProfOnPrimaryContainer,
    secondary = ProfSecondary,
    onSecondary = ProfOnSecondary,
    secondaryContainer = ProfSecondaryContainer,
    onSecondaryContainer = ProfOnSecondaryContainer,
    background = ProfOnBackground, // dark charcoal
    onBackground = ProfBackground,  // light gray blue
    surface = ProfOnBackground,
    onSurface = ProfBackground,
    surfaceVariant = ProfOnBackground,
    onSurfaceVariant = ProfBackground,
    outline = ProfOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We disable dynamic color by default so our custom professional theme is always used
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> ProfessionalDarkColorScheme
        else -> ProfessionalColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
