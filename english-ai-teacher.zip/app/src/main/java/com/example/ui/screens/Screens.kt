package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.data.model.*
import com.example.utils.AndroidTextToSpeech
import java.util.Calendar
import com.example.utils.SpeechRecognizerHelper
import com.example.viewmodel.ChatViewModel
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.PronunciationViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.launch

// --- 1. DASHBOARD SCREEN ---

@Composable
fun DashboardScreen(
    mainViewModel: MainViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToLessons: () -> Unit,
    onNavigateToVocab: () -> Unit,
    onNavigateToPronunciation: () -> Unit,
    onNavigateToQuizzes: () -> Unit
) {
    val stats by mainViewModel.userStats.collectAsStateWithLifecycle()
    val lessonProg by mainViewModel.lessonProgress.collectAsStateWithLifecycle()
    val vocabProg by mainViewModel.vocabProgress.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val xp = stats?.totalXp ?: 0
    val streak = stats?.currentStreak ?: 0
    val completedLessons = stats?.lessonsCompletedCount ?: 0
    val masteredWords = stats?.wordsMasteredCount ?: 0

    // Challenge Progress Calculations
    val todayCompletedLesson = lessonProg.any { it.isCompleted && isToday(it.completedAt) }
    val todayMasteredWordsCount = vocabProg.count { it.isMastered && isToday(it.lastPracticedAt) }
    val isChallengeEligible = todayCompletedLesson && todayMasteredWordsCount >= 1
    val isChallengeClaimed = mainViewModel.isDailyChallengeCompleted()

    Scaffold(
        topBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "English AI Teacher",
                                fontSize = 21.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1D1B20)
                            )
                            Text(
                                text = "MALAYALAM EDITION",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.5.sp,
                                color = Color.Gray
                            )
                        }
                        Row(
                            modifier = Modifier
                                .background(Color(0xFFE8DEF8), shape = RoundedCornerShape(100.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = Color(0xFF21005D),
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "$streak Days",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF21005D)
                            )
                        }
                    }
                    HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)
                }
            }
        },
        containerColor = Color(0xFFF3F4F9)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome and Mascot Banner
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFD3E3FD)),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "CURRENT PROGRESS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF001D35),
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Info",
                                tint = Color(0xFF001D35),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_teacher_avatar),
                                contentDescription = "English AI Teacher Owl Mascot",
                                modifier = Modifier
                                    .size(70.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .padding(4.dp),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "സുസ്വാഗതം! 👋",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF001D35)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "ഞാൻ നിങ്ങളുടെ English AI Teacher ആണ്.",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF001D35).copy(alpha = 0.8f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom elegant thin progress bar matching HTML:
                        val progressFraction = if (StaticData.lessons.isNotEmpty()) {
                            completedLessons.toFloat() / StaticData.lessons.size.toFloat()
                        } else {
                            0f
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .background(Color.White.copy(alpha = 0.3f), shape = CircleShape)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(fraction = progressFraction.coerceIn(0f, 1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFF0B57D0), shape = CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val percent = (progressFraction * 100).toInt()
                        val lessonsLeft = StaticData.lessons.size - completedLessons
                        Text(
                            text = "$percent% Complete • $lessonsLeft lessons left",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF001D35).copy(alpha = 0.8f)
                        )
                    }
                }
            }

        // Stats Card (Streak and XP)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("stats_streak_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Streak",
                            tint = Color(0xFFFF5722),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Streak", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$streak Days",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("stats_xp_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "XP Points",
                            tint = Color(0xFFFFC107),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Total XP", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "$xp XP",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Daily Challenge Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isChallengeClaimed) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.secondaryContainer
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("daily_challenge_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Daily Challenge",
                            tint = Color(0xFFFF9800),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ഇന്നത്തെ വെല്ലുവിളി (Daily Challenge)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "1 പാഠം പൂർത്തിയാക്കുകയും 1 പുതിയ വാക്ക് പഠിക്കുകയും ചെയ്യുക!",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Progress bars/indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "📖 Lesson: " + (if (todayCompletedLesson) "പൂർത്തിയായി (1/1)" else "ബാക്കി (0/1)"),
                            fontSize = 13.sp,
                            fontWeight = if (todayCompletedLesson) FontWeight.Bold else FontWeight.Normal,
                            color = if (todayCompletedLesson) Color(0xFF2E7D32) else Color.DarkGray
                        )
                        Text(
                            text = "🔤 Vocabulary: " + (if (todayMasteredWordsCount >= 1) "പൂർത്തിയായി ($todayMasteredWordsCount/1)" else "ബാക്കി ($todayMasteredWordsCount/1)"),
                            fontSize = 13.sp,
                            fontWeight = if (todayMasteredWordsCount >= 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (todayMasteredWordsCount >= 1) Color(0xFF2E7D32) else Color.DarkGray
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isChallengeClaimed) {
                        Button(
                            onClick = {},
                            enabled = false,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = "Done")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ഇന്നത്തെ വെല്ലുവിളി പൂർത്തിയായി! (+100 XP)")
                        }
                    } else {
                        Button(
                            onClick = {
                                if (isChallengeEligible) {
                                    mainViewModel.completeDailyChallenge()
                                    Toast.makeText(context, "വെല്ലുവിളി പൂർത്തിയാക്കി! +100 XP 🏆", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "പാഠങ്ങളും വാക്കുകളും പൂർത്തിയാക്കുക!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = isChallengeEligible,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isChallengeEligible) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isChallengeEligible) "ക്ലെയിം ചെയ്യുക (+100 XP!)" else "വെല്ലുവിളി പൂർത്തിയാക്കുക")
                        }
                    }
                }
            }
        }

        // Offline / AI Warning banner
        if (!mainViewModel.isAiAvailable()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Warning",
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ഓഫ്‌ലൈൻ മോഡ് സജീവമാണ്",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFFE65100)
                            )
                            Text(
                                text = "Gemini AI സേവനങ്ങൾ ഇപ്പോൾ ലഭ്യമല്ല. എങ്കിലും ഓഫ്‌ലൈൻ വഴി എല്ലാ പാഠങ്ങളും വ്യാകരണ ചോദ്യങ്ങളും പരിശീലനങ്ങളും താങ്കൾക്ക് പൂർണ്ണമായി ഉപയോഗിക്കാം!",
                                fontSize = 12.sp,
                                color = Color(0xFFE65100)
                            )
                        }
                    }
                }
            }
        }

        // Main Quick Actions Grid
        item {
            Text(text = "പഠന വിഭാഗങ്ങൾ (Learning Modules)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // English Chat With AI Teacher
                DashboardButton(
                    title = "AI ചർച്ചാമുറി (AI Tutor Chat)",
                    subtitle = "സംസാരിച്ചു കൊണ്ട് ഇംഗ്ലീഷ് പഠിക്കാം",
                    icon = Icons.AutoMirrored.Default.Chat,
                    color = MaterialTheme.colorScheme.primary,
                    tag = "chat_nav_btn",
                    onClick = onNavigateToChat
                )

                // Lessons
                DashboardButton(
                    title = "വ്യാകരണ പാഠങ്ങൾ (Grammar Lessons)",
                    subtitle = "മൊത്തം ${StaticData.lessons.size} പാഠങ്ങൾ",
                    icon = Icons.Default.Book,
                    color = Color(0xFF2E7D32),
                    tag = "lessons_nav_btn",
                    onClick = onNavigateToLessons
                )

                // Pronunciation
                DashboardButton(
                    title = "ഉച്ചാരണ പരിശീലനം (Pronunciation Practice)",
                    subtitle = "ശബ്ദം റെക്കോർഡ് ചെയ്തു പരിശോധിക്കുക",
                    icon = Icons.Default.Mic,
                    color = Color(0xFFD84315),
                    tag = "pron_nav_btn",
                    onClick = onNavigateToPronunciation
                )

                // Vocabulary
                DashboardButton(
                    title = "പദശേഖരം (Vocabulary Flashcards)",
                    subtitle = "നിത്യോപയോഗ ഇംഗ്ലീഷ് വാക്കുകൾ",
                    icon = Icons.Default.Translate,
                    color = Color(0xFF00838F),
                    tag = "vocab_nav_btn",
                    onClick = onNavigateToVocab
                )

                // Quizzes
                DashboardButton(
                    title = "പരിശീലന പരീക്ഷകൾ (Quizzes)",
                    subtitle = "ബുദ്ധിപരമായ ചോദ്യോത്തരങ്ങൾ",
                    icon = Icons.Default.Quiz,
                    color = Color(0xFF6A1B9A),
                    tag = "quiz_nav_btn",
                    onClick = onNavigateToQuizzes
                )
            }
        }
    }
}
}

@Composable
fun DashboardButton(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(tag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1.0f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF1D1B20)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = "Open",
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

// Helpers
private fun isToday(timestamp: Long): Boolean {
    val cal1 = Calendar.getInstance()
    cal1.timeInMillis = timestamp
    val cal2 = Calendar.getInstance()
    return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
            cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
}


// --- 2. LESSONS SCREEN ---

@Composable
fun LessonsScreen(
    mainViewModel: MainViewModel,
    tts: AndroidTextToSpeech,
    onBack: () -> Unit
) {
    val progressList by mainViewModel.lessonProgress.collectAsStateWithLifecycle()
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    val context = LocalContext.current

    if (selectedLesson == null) {
        // Lessons List Screen
        Scaffold(
            topBar = {
                OptInTopAppBar(
                    title = "വ്യാകരണ പാഠങ്ങൾ",
                    onBack = onBack
                )
            },
            containerColor = Color(0xFFF3F4F9)
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(StaticData.lessons) { lesson ->
                    val isCompleted = progressList.any { it.lessonId == lesson.id && it.isCompleted }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedLesson = lesson }
                            .testTag("lesson_card_${lesson.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isCompleted) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.PlayArrow,
                                    contentDescription = "Status",
                                    tint = if (isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = lesson.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF1D1B20)
                                )
                                Text(
                                    text = lesson.malayalamTitle,
                                    fontSize = 13.sp,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = lesson.shortDescription,
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                            if (isCompleted) {
                                Badge(containerColor = Color(0xFFE8F5E9), contentColor = Color(0xFF2E7D32)) {
                                    Text("പൂർത്തിയായി", modifier = Modifier.padding(4.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Lesson Detail View
        val lesson = selectedLesson!!
        val isCompleted = progressList.any { it.lessonId == lesson.id && it.isCompleted }

        Scaffold(
            topBar = {
                OptInTopAppBar(
                    title = lesson.title,
                    onBack = { selectedLesson = null }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                // Header Intro
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = lesson.malayalamTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lesson.descriptionMalayalam,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scrollable Lesson Sections
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(lesson.content) { section ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = section.englishText,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { tts.speak(section.englishText) }) {
                                        Icon(
                                            imageVector = Icons.Default.VolumeUp,
                                            contentDescription = "Speak Sentence",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                Text(
                                    text = "🗣️ ഉച്ചാരണം: ${section.pronunciationMalayalam}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFFE65100)
                                )
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                Text(
                                    text = "✍️ അർത്ഥം: ${section.translationMalayalam}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = section.explanationMalayalam,
                                    fontSize = 13.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Complete Action Button
                if (isCompleted) {
                    Button(
                        onClick = { selectedLesson = null },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("പാഠങ്ങൾ പട്ടികയിലേക്ക് മടങ്ങുക")
                    }
                } else {
                    Button(
                        onClick = {
                            mainViewModel.completeLesson(lesson.id)
                            Toast.makeText(context, "പാഠം പൂർത്തിയായി! +50 XP 🏆", Toast.LENGTH_SHORT).show()
                            selectedLesson = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("complete_lesson_btn")
                    ) {
                        Text("പൂർത്തിയായി എന്ന് രേഖപ്പെടുത്തുക (+50 XP)")
                    }
                }
            }
        }
    }
}


// --- 3. VOCABULARY SCREEN ---

@Composable
fun VocabScreen(
    mainViewModel: MainViewModel,
    tts: AndroidTextToSpeech,
    onBack: () -> Unit
) {
    val progressList by mainViewModel.vocabProgress.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            OptInTopAppBar(
                title = "പദശേഖരം (Vocabulary)",
                onBack = onBack
            )
        },
        containerColor = Color(0xFFF3F4F9)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(StaticData.vocabularyList) { vocab ->
                val isMastered = progressList.any { it.vocabId == vocab.id && it.isMastered }

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isMastered) Color(0xFFF1F8E9) else Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isMastered) Color(0xFFC5E1A5) else Color(0xFFE2E8F0)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("vocab_card_${vocab.id}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = vocab.word,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "🗣️ ${vocab.pronunciationMalayalam}",
                                    fontSize = 13.sp,
                                    color = Color(0xFFD84315),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            
                            Row {
                                IconButton(onClick = { tts.speak(vocab.word) }) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Speak Word",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                
                                IconButton(
                                    onClick = {
                                        mainViewModel.practiceVocab(vocab.id, !isMastered)
                                        val msg = if (!isMastered) "പഠിച്ചു കഴിഞ്ഞു! +20 XP 🏆" else "ബാക്കി വെച്ചിരിക്കുന്നു"
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isMastered) Icons.Default.CheckCircle else Icons.Default.CheckCircleOutline,
                                        contentDescription = "Mark Mastered",
                                        tint = if (isMastered) Color(0xFF2E7D32) else Color.Gray
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "മലയാളം അർത്ഥം: ${vocab.malayalamMeaning}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "ExampleEnglish:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = vocab.exampleEnglish,
                            fontSize = 14.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = Color(0xFF1D1B20),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                        Text(
                            text = vocab.exampleMalayalam,
                            fontSize = 13.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }
            }
        }
    }
}


// --- 4. PRONUNCIATION SCREEN ---

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PronunciationScreen(
    mainViewModel: MainViewModel,
    pronunciationViewModel: PronunciationViewModel,
    tts: AndroidTextToSpeech,
    onBack: () -> Unit
) {
    val targetSentence by pronunciationViewModel.targetSentence.collectAsStateWithLifecycle()
    val recognizedText by pronunciationViewModel.userSpeechResult.collectAsStateWithLifecycle()
    val feedback by pronunciationViewModel.evaluationFeedback.collectAsStateWithLifecycle()
    val isEvaluating by pronunciationViewModel.isEvaluating.collectAsStateWithLifecycle()
    val isOfflineEval by pronunciationViewModel.isOfflineEvaluation.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val micPermissionState = rememberPermissionState(permission = Manifest.permission.RECORD_AUDIO)

    val speechRecognizerHelper = remember { SpeechRecognizerHelper(context) }
    val isListening by speechRecognizerHelper.isListening.collectAsStateWithLifecycle()
    val spokenText by speechRecognizerHelper.recognizedText.collectAsStateWithLifecycle()
    val speechError by speechRecognizerHelper.error.collectAsStateWithLifecycle()

    DisposableEffect(Unit) {
        onDispose {
            speechRecognizerHelper.destroy()
        }
    }

    // Capture Speech Result to Evaluate
    LaunchedEffect(spokenText) {
        if (spokenText.isNotEmpty() && !isListening) {
            pronunciationViewModel.setSpeechResultAndEvaluate(spokenText) {
                mainViewModel.earnPronunciationXp()
            }
        }
    }

    Scaffold(
        topBar = {
            OptInTopAppBar(
                title = "ഉച്ചാരണ പരിശീലനം",
                onBack = onBack
            )
        },
        containerColor = Color(0xFFF3F4F9)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Objective Header
            Text(
                text = "താഴെ കൊടുത്തിരിക്കുന്ന വാചകം ഉച്ചത്തിൽ വ്യക്തമായി വായിക്കുക:",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1D1B20),
                textAlign = TextAlign.Center
            )

            // Target Sentence display card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD3E3FD)),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(0xFFADC6FF)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("target_sentence_card")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = targetSentence,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { tts.speak(targetSentence) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF001D35))
                    ) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = "Hear native pron")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ശബ്ദം കേൾക്കുക (Listen)")
                    }
                }
            }

            // Record/Speak interface
            if (!micPermissionState.status.isGranted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "മൈക്രോഫോൺ അനുമതി ആവശ്യമാണ്",
                            color = Color(0xFFC62828),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "സംസാരിക്കുന്നത് റെക്കോർഡ് ചെയ്യാനും വിലയിരുത്താനും ദയവായി അനുമതി നൽകുക.",
                            color = Color(0xFFC62828),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { micPermissionState.launchPermissionRequest() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                        ) {
                            Text("അനുമതി നൽകുക (Grant Permission)")
                        }
                    }
                }
            } else {
                // Mic Is Ready
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (isListening) {
                                speechRecognizerHelper.stopListening()
                            } else {
                                speechRecognizerHelper.startListening()
                            }
                        },
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(
                                if (isListening) Color(0xFFE53935) else MaterialTheme.colorScheme.primary
                            )
                            .testTag("pron_mic_btn")
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Mic Trigger",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Text(
                        text = if (isListening) "സംസാരിക്കൂ... (Listening)" else "റെക്കോർഡ് ചെയ്യാൻ അമർത്തുക",
                        fontWeight = FontWeight.Bold,
                        color = if (isListening) Color(0xFFE53935) else Color.DarkGray
                    )
                }
            }

            // Feedback/Status display
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (isEvaluating) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("നിങ്ങളുടെ ശബ്ദം വിലയിരുത്തുന്നു (Evaluating...)", fontSize = 13.sp)
                    }
                } else if (speechError != null) {
                    Text(
                        text = "⚠️ പിശക്: $speechError\nദയവായി വീണ്ടും ശ്രമിക്കുക.",
                        color = Color.Red,
                        textAlign = TextAlign.Center
                    )
                } else if (feedback != null) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOfflineEval) Color(0xFFFFF3E0) else Color(0xFFE8F5E9)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, if (isOfflineEval) Color(0xFFFFB74D) else Color(0xFFA5D6A7)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("evaluation_feedback_card")
                    ) {
                        LazyColumn(modifier = Modifier.padding(16.dp)) {
                            item {
                                Text(
                                    text = feedback!!,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "ഉച്ചാരണ സ്കോർ ഇവിടെ കാണാം!",
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Action Buttons
            Button(
                onClick = { pronunciationViewModel.nextSentence() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("അടുത്ത വാചകം പരിശീലിക്കുക (Next)")
            }
        }
    }
}


// --- 5. QUIZ SCREEN ---

@Composable
fun QuizScreen(
    mainViewModel: MainViewModel,
    onBack: () -> Unit
) {
    val scores by mainViewModel.quizScores.collectAsStateWithLifecycle()
    var activeQuiz by remember { mutableStateOf<Quiz?>(null) }
    val context = LocalContext.current

    if (activeQuiz == null) {
        // Quizzes List View
        Scaffold(
            topBar = {
                OptInTopAppBar(
                    title = "പരിശീലന പരീക്ഷകൾ",
                    onBack = onBack
                )
            },
            containerColor = Color(0xFFF3F4F9)
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(StaticData.quizzes) { quiz ->
                    val high = scores.find { it.quizId == quiz.id }?.highScore ?: 0
                    val total = quiz.questions.size

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeQuiz = quiz }
                            .testTag("quiz_card_${quiz.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFF2B8B5)), // red/pink accent bubble matching quiz
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Quiz,
                                    contentDescription = "Quiz",
                                    tint = Color(0xFF601410)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = quiz.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF1D1B20)
                                )
                                Text(
                                    text = quiz.malayalamTitle,
                                    fontSize = 13.sp,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Category: ${quiz.category} • $total Questions",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "High Score",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "$high/$total",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF601410)
                                )
                            }
                        }
                    }
                }
            }
        }
    } else {
        // Active Quiz Gameplay Screen
        val quiz = activeQuiz!!
        var questionIndex by remember { mutableIntStateOf(0) }
        var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
        var isAnswerConfirmed by remember { mutableStateOf(false) }
        var correctAnswersCount by remember { mutableIntStateOf(0) }
        var isQuizCompleted by remember { mutableStateOf(false) }

        val question = quiz.questions[questionIndex]

        Scaffold(
            topBar = {
                OptInTopAppBar(
                    title = quiz.title,
                    onBack = { activeQuiz = null }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (!isQuizCompleted) {
                    // Question index indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ചോദ്യം ${questionIndex + 1} of ${quiz.questions.size}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        LinearProgressIndicator(
                            progress = { (questionIndex + 1).toFloat() / quiz.questions.size },
                            modifier = Modifier
                                .width(120.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }

                    // Question Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = question.questionText,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(24.dp)
                        )
                    }

                    // MCQ Options list
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        question.options.forEachIndexed { index, option ->
                            val isSelected = selectedOptionIndex == index
                            val isCorrectAnswer = index == question.correctOptionIndex

                            val cardColor = when {
                                isAnswerConfirmed && isCorrectAnswer -> Color(0xFFC8E6C9) // Green for correct
                                isAnswerConfirmed && isSelected && !isCorrectAnswer -> Color(0xFFFFCDD2) // Red for wrong selected
                                isSelected -> MaterialTheme.colorScheme.secondaryContainer
                                else -> MaterialTheme.colorScheme.surface
                            }

                            val borderStroke = if (isSelected) {
                                CardDefaults.outlinedCardBorder().copy(width = 2.dp)
                            } else {
                                CardDefaults.outlinedCardBorder()
                            }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = cardColor),
                                border = borderStroke,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !isAnswerConfirmed) {
                                        selectedOptionIndex = index
                                    }
                                    .testTag("option_$index")
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { if (!isAnswerConfirmed) selectedOptionIndex = index },
                                        enabled = !isAnswerConfirmed
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = option,
                                        fontSize = 15.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }

                    // Explanation & Guidance
                    if (isAnswerConfirmed) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "💡 വിശദീകരണം (Explanation):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFFE65100)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = question.explanationMalayalam,
                                    fontSize = 13.sp,
                                    color = Color.Black
                                )
                            }
                        }
                    }

                    // Confirm / Next Button
                    Button(
                        onClick = {
                            if (!isAnswerConfirmed) {
                                if (selectedOptionIndex == question.correctOptionIndex) {
                                    correctAnswersCount++
                                }
                                isAnswerConfirmed = true
                            } else {
                                if (questionIndex + 1 < quiz.questions.size) {
                                    questionIndex++
                                    selectedOptionIndex = null
                                    isAnswerConfirmed = false
                                } else {
                                    isQuizCompleted = true
                                    mainViewModel.saveQuizScore(quiz.id, correctAnswersCount, quiz.questions.size)
                                }
                            }
                        },
                        enabled = selectedOptionIndex != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quiz_action_btn")
                    ) {
                        Text(
                            text = when {
                                !isAnswerConfirmed -> "ഉത്തരം പരിശോധിക്കുക"
                                questionIndex + 1 < quiz.questions.size -> "അടുത്ത ചോദ്യം"
                                else -> "പരീക്ഷ പൂർത്തിയാക്കുക"
                            }
                        )
                    }
                } else {
                    // Quiz End Summary Scorecard
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Trophy",
                            tint = Color(0xFFFFC107),
                            modifier = Modifier.size(100.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "പരീക്ഷ പൂർത്തിയായി!",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "നിങ്ങളുടെ സ്കോർ:",
                            fontSize = 16.sp,
                            color = Color.Gray
                        )
                        Text(
                            text = "$correctAnswersCount / ${quiz.questions.size}",
                            fontSize = 48.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        val gainXp = correctAnswersCount * 15
                        Text(
                            text = "+$gainXp XP നേടി! 🏆",
                            fontSize = 18.sp,
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(32.dp))

                        Button(
                            onClick = { activeQuiz = null },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("പട്ടികയിലേക്ക് മടങ്ങുക")
                        }
                    }
                }
            }
        }
    }
}


// --- 6. CHAT SCREEN (AI TUTOR CHAT) ---

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ChatScreen(
    mainViewModel: MainViewModel,
    chatViewModel: ChatViewModel,
    tts: AndroidTextToSpeech,
    onBack: () -> Unit
) {
    val messages by chatViewModel.messages.collectAsStateWithLifecycle()
    val isLoading by chatViewModel.isLoading.collectAsStateWithLifecycle()
    val chatError by chatViewModel.error.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val context = LocalContext.current
    val micPermissionState = rememberPermissionState(permission = Manifest.permission.RECORD_AUDIO)

    val speechRecognizerHelper = remember { SpeechRecognizerHelper(context) }
    val isListening by speechRecognizerHelper.isListening.collectAsStateWithLifecycle()
    val spokenText by speechRecognizerHelper.recognizedText.collectAsStateWithLifecycle()

    DisposableEffect(Unit) {
        onDispose {
            speechRecognizerHelper.destroy()
        }
    }

    // Capture Speech Result to chat input field
    LaunchedEffect(spokenText) {
        if (spokenText.isNotEmpty()) {
            textInput = spokenText
        }
    }

    // Scroll to bottom on new messages
    LaunchedEffect(messages.size, isLoading) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            OptInTopAppBar(
                title = "English AI Teacher",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { chatViewModel.clearChat() }) {
                        Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear Chat History")
                    }
                }
            )
        },
        containerColor = Color(0xFFF3F4F9)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Chat Message Stream
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(messages) { message ->
                    val alignment = if (message.isUser) Alignment.End else Alignment.Start
                    val containerColor = if (message.isUser) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                    val textColor = if (message.isUser) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = alignment
                    ) {
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (!message.isUser) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_teacher_avatar),
                                    contentDescription = "Teacher Mascot",
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            Card(
                                shape = RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (message.isUser) 16.dp else 4.dp,
                                    bottomEnd = if (message.isUser) 4.dp else 16.dp
                                ),
                                colors = CardDefaults.cardColors(containerColor = containerColor),
                                modifier = Modifier
                                    .widthIn(max = 280.dp)
                                    .testTag(if (message.isUser) "user_msg" else "ai_msg")
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = message.text,
                                        color = textColor,
                                        fontSize = 15.sp,
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = { tts.speak(message.text) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.VolumeUp,
                                                contentDescription = "Speak message",
                                                tint = textColor.copy(alpha = 0.7f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "English AI Teacher ടൈപ്പ് ചെയ്യുന്നു...",
                                fontSize = 13.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // Chat input control panel
            Surface(
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Suggested dynamic question chips for Malayalam speakers
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        SuggestionChip(
                            onClick = { textInput = "How to say 'എനിക്ക് സുഖമാണ്' in English?" },
                            label = { Text("എനിക്ക് സുഖമാണ്?", fontSize = 11.sp) }
                        )
                        SuggestionChip(
                            onClick = { textInput = "Explain 'Simple Past Tense' in Malayalam." },
                            label = { Text("Past Tense തരാമോ?", fontSize = 11.sp) }
                        )
                        SuggestionChip(
                            onClick = { textInput = "Give me 3 greeting phrases." },
                            label = { Text("3Greetings?", fontSize = 11.sp) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Mic Button
                        IconButton(
                            onClick = {
                                if (!micPermissionState.status.isGranted) {
                                    micPermissionState.launchPermissionRequest()
                                } else {
                                    if (isListening) {
                                        speechRecognizerHelper.stopListening()
                                    } else {
                                        speechRecognizerHelper.startListening()
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isListening) Color(0xFFE53935) else MaterialTheme.colorScheme.primaryContainer
                                )
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                contentDescription = "Speech Record Icon",
                                tint = if (isListening) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Text Field Input
                        TextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("ഇവിടെ ടൈപ്പ് ചെയ്യുക (Ask anything...)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_text_input"),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            singleLine = false,
                            maxLines = 3
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Send Button
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    chatViewModel.sendMessage(textInput)
                                    textInput = ""
                                }
                            },
                            enabled = textInput.isNotBlank() && !isLoading,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    if (textInput.isNotBlank()) MaterialTheme.colorScheme.primary else Color.LightGray
                                )
                                .testTag("chat_send_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send Button",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}


// --- GENERIC CUSTOM RE-USABLE COMPONENTS ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptInTopAppBar(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Column {
        TopAppBar(
            title = {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            actions = actions,
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.White,
                titleContentColor = Color(0xFF1D1B20),
                navigationIconContentColor = MaterialTheme.colorScheme.primary,
                actionIconContentColor = MaterialTheme.colorScheme.primary
            )
        )
        HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)
    }
}
