package com.example.api

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini API Moshi Data Classes ---

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @Json(name = "temperature") val temperature: Double? = null,
    @Json(name = "maxOutputTokens") val maxOutputTokens: Int? = null
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content?
)

// --- Retrofit Interface ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

// --- Retrofit Client ---

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val service: GeminiApiService by lazy {
        retrofit.create(GeminiApiService::class.java)
    }

    // Default System Instruction for English AI Teacher
    private val systemInstructionContent = Content(
        parts = listOf(
            Part(
                text = "You are 'English AI Teacher', a professional, extremely patient, and friendly English Language Tutor specialized in helping Malayalam speakers learn English from scratch. " +
                        "IMPORTANT RULES:\n" +
                        "1. ALWAYS explain difficult concepts, grammar, and vocabulary in simple Malayalam (using Malayalam script), with English examples and pronunciations in Malayalam brackets where appropriate.\n" +
                        "2. Keep lessons extremely encouraging, clear, and beginner-friendly.\n" +
                        "3. Use short sentences and structured lists (bullet points) so Malayalam speakers can follow along easily.\n" +
                        "4. When correcting the user, be very polite and encourage them to try again. Highlight what they got right before correcting errors.\n" +
                        "5. If a user asks a question in English or Malayalam, answer and explain in Malayalam while giving English translation equivalents."
            )
        )
    )

    /**
     * Call Gemini to get a response for our English AI Teacher chat or lessons.
     * Handles key availability check and network failures gracefully.
     */
    suspend fun chatWithTeacher(history: List<Content>, userPrompt: String): Result<String> {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return Result.failure(IllegalStateException("API key is not configured. Please add GEMINI_API_KEY in your Secrets panel."))
        }

        val chatContents = history.toMutableList().apply {
            add(Content(parts = listOf(Part(text = userPrompt))))
        }

        val request = GeminiRequest(
            contents = chatContents,
            generationConfig = GenerationConfig(temperature = 0.7),
            systemInstruction = systemInstructionContent
        )

        return try {
            val response = service.generateContent(apiKey, request)
            val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (replyText != null) {
                Result.success(replyText)
            } else {
                Result.failure(Exception("No valid answer received from the AI model."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Ask Gemini to give pronunciation feedback on how well the user pronounced a target sentence, based on speech transcription.
     */
    suspend fun getPronunciationFeedback(targetSentence: String, userTranscription: String): Result<String> {
        val prompt = "The student was asked to pronounce this English sentence: '$targetSentence'.\n" +
                "The automatic speech recognition transcribed their voice as: '$userTranscription'.\n" +
                "Please analyze the transcription and explain any pronunciation differences or errors. Give simple, actionable tips in Malayalam (using Malayalam script) on how they can improve, and rate their attempt out of 5 stars (e.g., ⭐⭐⭐⭐). Be encouraging and warm!"
        
        return chatWithTeacher(emptyList(), prompt)
    }
}
