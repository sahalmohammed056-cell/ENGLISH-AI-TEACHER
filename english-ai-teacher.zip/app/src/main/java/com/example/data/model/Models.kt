package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- Room Entities for Local Progress Tracking ---

@Entity(tableName = "lesson_progress")
data class LessonProgress(
    @PrimaryKey val lessonId: String,
    val isCompleted: Boolean,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "vocab_progress")
data class VocabProgress(
    @PrimaryKey val vocabId: String,
    val isMastered: Boolean,
    val timesPracticed: Int = 0,
    val lastPracticedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quiz_score")
data class QuizScore(
    @PrimaryKey val quizId: String,
    val highScore: Int,
    val totalQuestions: Int,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_stats")
data class UserStats(
    @PrimaryKey val id: Int = 1,
    val totalXp: Int = 0,
    val currentStreak: Int = 0,
    val lastActiveDate: String = "", // YYYY-MM-DD
    val lessonsCompletedCount: Int = 0,
    val wordsMasteredCount: Int = 0,
    val lastChallengeDate: String = "" // YYYY-MM-DD
)

// --- Domain Models ---

data class Lesson(
    val id: String,
    val title: String,
    val malayalamTitle: String,
    val shortDescription: String,
    val descriptionMalayalam: String,
    val content: List<LessonSection>
)

data class LessonSection(
    val englishText: String,
    val pronunciationMalayalam: String,
    val translationMalayalam: String,
    val explanationMalayalam: String
)

data class Vocabulary(
    val id: String,
    val word: String,
    val pronunciationMalayalam: String,
    val malayalamMeaning: String,
    val exampleEnglish: String,
    val exampleMalayalam: String
)

data class Question(
    val id: String,
    val questionText: String,
    val options: List<String>,
    val correctOptionIndex: Int,
    val explanationMalayalam: String
)

data class Quiz(
    val id: String,
    val title: String,
    val malayalamTitle: String,
    val category: String, // "Grammar" or "Vocabulary"
    val questions: List<Question>
)

// --- Static Preloaded Curriculum & Data ---

object StaticData {

    val lessons = listOf(
        Lesson(
            id = "g1_greetings",
            title = "Greetings & Introductions",
            malayalamTitle = "അഭിവാദനങ്ങളും പരിചയപ്പെടലും",
            shortDescription = "Learn how to greet someone and introduce yourself in English.",
            descriptionMalayalam = "ഒരാളെ ആദ്യമായി കാണുമ്പോൾ എങ്ങനെ സംസാരിക്കണം എന്നും നമ്മളെത്തന്നെ എങ്ങനെ പരിചയപ്പെടുത്തണം എന്നും പഠിക്കാം.",
            content = listOf(
                LessonSection(
                    englishText = "Hello, how are you?",
                    pronunciationMalayalam = "ഹലോ, ഹൗ ആർ യു?",
                    translationMalayalam = "ഹലോ, സുഖമാണോ?",
                    explanationMalayalam = "ഒരാളെ കാണുമ്പോൾ ഏറ്റവും സാധാരണയായി ഉപയോഗിക്കുന്ന അഭിവാദനമാണിത്."
                ),
                LessonSection(
                    englishText = "I am fine, thank you.",
                    pronunciationMalayalam = "ഐ ആം ഫൈൻ, ഥാങ്ക് യു.",
                    translationMalayalam = "എനിക്ക് സുഖമാണ്, നന്ദി.",
                    explanationMalayalam = "സുഖമാണോ എന്ന് ചോദിച്ചാൽ മറുപടിയായി ഇത് പറയാം."
                ),
                LessonSection(
                    englishText = "What is your name?",
                    pronunciationMalayalam = "വാട്ട് ഈസ് യുവർ നെയിം?",
                    translationMalayalam = "താങ്കളുടെ പേരെന്താണ്?",
                    explanationMalayalam = "പേര് ചോദിക്കാനുള്ള ലളിതമായ ചോദ്യം."
                ),
                LessonSection(
                    englishText = "My name is Arun.",
                    pronunciationMalayalam = "മൈ നെയിം ഈസ് അരുൺ.",
                    translationMalayalam = "എന്റെ പേര് അരുൺ എന്നാണ്.",
                    explanationMalayalam = "നിങ്ങളുടെ പേര് പറയാൻ 'My name is [പേര്]' എന്ന് ഉപയോഗിക്കുക."
                ),
                LessonSection(
                    englishText = "Nice to meet you.",
                    pronunciationMalayalam = "നൈസ് ടു മീറ്റ് യു.",
                    translationMalayalam = "താങ്കളെ പരിചയപ്പെട്ടതിൽ സന്തോഷം.",
                    explanationMalayalam = "ഒരാളെ ആദ്യമായി പരിചയപ്പെട്ടു കഴിയുമ്പോൾ സ്നേഹത്തോടെ പറയാൻ ഇത് ഉപയോഗിക്കാം."
                )
            )
        ),
        Lesson(
            id = "g2_pronouns",
            title = "Personal Pronouns",
            malayalamTitle = "വ്യക്തിഗത സർവ്വനാമങ്ങൾ",
            shortDescription = "Master 'I', 'You', 'He', 'She', 'We', and 'They'.",
            descriptionMalayalam = "പേരുകൾക്ക് പകരം ഉപയോഗിക്കുന്ന വാക്കുകളാണ് Pronouns. ഇവ ഇംഗ്ലീഷ് സംസാരിക്കാൻ ഏറ്റവും അത്യാവശ്യമാണ്.",
            content = listOf(
                LessonSection(
                    englishText = "I am a student.",
                    pronunciationMalayalam = "ഐ ആം എ സ്റ്റുഡന്റ്.",
                    translationMalayalam = "ഞാൻ ഒരു വിദ്യാർത്ഥിയാണ്.",
                    explanationMalayalam = "'I' എന്നാൽ 'ഞാൻ' എന്നാണ് അർത്ഥം. നമ്മളെക്കുറിച്ച് പറയാൻ ഇത് ഉപയോഗിക്കുന്നു."
                ),
                LessonSection(
                    englishText = "You are my friend.",
                    pronunciationMalayalam = "യു ആർ മൈ ഫ്രണ്ട്.",
                    translationMalayalam = "നീ/താങ്കൾ എന്റെ സുഹൃത്താണ്.",
                    explanationMalayalam = "'You' എന്നാൽ 'നീ' അല്ലെങ്കിൽ 'താങ്കൾ' / 'നിങ്ങൾ' എന്നാണ് അർത്ഥം."
                ),
                LessonSection(
                    englishText = "He is a doctor.",
                    pronunciationMalayalam = "ഹീ ഈസ് എ ഡോക്ടർ.",
                    translationMalayalam = "അവൻ ഒരു ഡോക്ടറാണ്.",
                    explanationMalayalam = "'He' എന്നാൽ 'അവൻ' അല്ലെങ്കിൽ 'അദ്ദേഹം' (പുരുഷന്മാർക്ക് പകരം) ഉപയോഗിക്കുന്നു."
                ),
                LessonSection(
                    englishText = "She is a teacher.",
                    pronunciationMalayalam = "ഷീ ഈസ് എ ടീച്ചർ.",
                    translationMalayalam = "അവൾ ഒരു അധ്യാപികയാണ്.",
                    explanationMalayalam = "'She' എന്നാൽ 'അവൾ' അല്ലെങ്കിൽ 'അവർ' (സ്ത്രീകൾക്ക് പകരം) ഉപയോഗിക്കുന്നു."
                ),
                LessonSection(
                    englishText = "We are learning English.",
                    pronunciationMalayalam = "വി ആർ ലേണിംഗ് ഇംഗ്ലീഷ്.",
                    translationMalayalam = "ഞങ്ങൾ ഇംഗ്ലീഷ് പഠിക്കുകയാണ്.",
                    explanationMalayalam = "'We' എന്നാൽ 'ഞങ്ങൾ' അല്ലെങ്കിൽ 'നമ്മൾ' എന്നാണ് അർത്ഥം."
                ),
                LessonSection(
                    englishText = "They are playing football.",
                    pronunciationMalayalam = "ഥേ ആർ പ്ലേയിംഗ് ഫുട്ബോൾ.",
                    translationMalayalam = "അവർ ഫുട്ബോൾ കളിക്കുകയാണ്.",
                    explanationMalayalam = "'They' എന്നാൽ 'അവർ' (ഒന്നിലധികം ആളുകളെക്കുറിച്ച് പറയാൻ) ഉപയോഗിക്കുന്നു."
                )
            )
        ),
        Lesson(
            id = "g3_to_be_verbs",
            title = "Verbs: Is, Am, Are",
            malayalamTitle = "ക്രിയകൾ: Is, Am, Are",
            shortDescription = "Learn how to express state of being using to-be verbs.",
            descriptionMalayalam = "വർത്തമാനകാലത്തിൽ ഒരാളുടെ അല്ലെങ്കിൽ ഒരു വസ്തുവിന്റെ അവസ്ഥ പറയാൻ 'Am', 'Is', 'Are' എന്നിവ എങ്ങനെ ഉപയോഗിക്കണമെന്ന് പഠിക്കാം.",
            content = listOf(
                LessonSection(
                    englishText = "I am happy.",
                    pronunciationMalayalam = "ഐ ആം ഹാപ്പി.",
                    translationMalayalam = "ഞാൻ സന്തോഷവാനാണ് / സന്തോഷവതിയാണ്.",
                    explanationMalayalam = "'I' എന്ന പ്രോനൗണിനൊപ്പം എപ്പോഴും 'am' മാത്രമേ ഉപയോഗിക്കാവൂ."
                ),
                LessonSection(
                    englishText = "He is busy today.",
                    pronunciationMalayalam = "ഹീ ഈസ് ബിസി ടുഡേ.",
                    translationMalayalam = "അവൻ ഇന്ന് തിരക്കിലാണ്.",
                    explanationMalayalam = "ഏകവചനങ്ങളായ (He, She, It, Arun) വാക്കുകൾക്കൊപ്പം 'is' ഉപയോഗിക്കുന്നു."
                ),
                LessonSection(
                    englishText = "The apple is red.",
                    pronunciationMalayalam = "ദി ആപ്പിൾ ഈസ് റെഡ്.",
                    translationMalayalam = "ആപ്പിൾ ചുവന്നതാണ്.",
                    explanationMalayalam = "ഒരു വസ്തുവിനെക്കുറിച്ച് പറയുമ്പോൾ 'is' ഉപയോഗിക്കുന്നു."
                ),
                LessonSection(
                    englishText = "We are tired.",
                    pronunciationMalayalam = "വി ആർ ടയേർഡ്.",
                    translationMalayalam = "ഞങ്ങൾ തളർന്നിരിക്കുന്നു.",
                    explanationMalayalam = "ബഹുവചനങ്ങളായ (We, They, You) വാക്കുകൾക്കൊപ്പം എപ്പോഴും 'are' ഉപയോഗിക്കുന്നു."
                )
            )
        ),
        Lesson(
            id = "g4_simple_present",
            title = "Simple Present Tense",
            malayalamTitle = "ലളിതമായ വർത്തമാനകാലം",
            shortDescription = "Express habits and universal truths.",
            descriptionMalayalam = "നമ്മുടെ ദിനചര്യകൾ (Habits), സ്ഥിരമായ കാര്യങ്ങൾ, പൊതുസത്യങ്ങൾ എന്നിവ പറയാൻ Simple Present Tense ഉപയോഗിക്കുന്നു.",
            content = listOf(
                LessonSection(
                    englishText = "I drink tea every morning.",
                    pronunciationMalayalam = "ഐ ഡ്രിങ്ക് ടീ എവരി മോണിംഗ്.",
                    translationMalayalam = "ഞാൻ എല്ലാ ദിവസവും രാവിലെ ചായ കുടിക്കാറുണ്ട്.",
                    explanationMalayalam = "ഒരു ശീലം അല്ലെങ്കിൽ നിത്യേന ചെയ്യുന്ന കാര്യം പറയാൻ ലളിതമായ ക്രിയ (drink) ഉപയോഗിക്കുന്നു."
                ),
                LessonSection(
                    englishText = "He speaks English very well.",
                    pronunciationMalayalam = "ഹീ സ്പീക്സ് ഇംഗ്ലീഷ് വെരി വെൽ.",
                    translationMalayalam = "അവൻ ഇംഗ്ലീഷ് വളരെ നന്നായി സംസാരിക്കും.",
                    explanationMalayalam = "കർത്താവ് ഏകവചനം (He, She, It) ആണെങ്കിൽ ക്രിയയുടെ കൂടെ 's' അല്ലെങ്കിൽ 'es' ചേർക്കണം (speak -> speaks)."
                ),
                LessonSection(
                    englishText = "The sun rises in the east.",
                    pronunciationMalayalam = "ദി സൺ റൈസസ് ഇൻ ദി ഈസ്റ്റ്.",
                    translationMalayalam = "സൂര്യൻ കിഴക്കുദിക്കുന്നു.",
                    explanationMalayalam = "ഇതൊരു പ്രപഞ്ചസത്യമാണ് (Universal Truth). ഇതിനും Simple Present Tense തന്നെ ഉപയോഗിക്കുന്നു."
                )
            )
        )
    )

    val vocabularyList = listOf(
        Vocabulary(
            id = "v1",
            word = "Hello",
            pronunciationMalayalam = "ഹലോ",
            malayalamMeaning = "ഹലോ / നമസ്കാരം",
            exampleEnglish = "Hello! Nice to meet you.",
            exampleMalayalam = "ഹലോ! താങ്കളെ പരിചയപ്പെട്ടതിൽ സന്തോഷം."
        ),
        Vocabulary(
            id = "v2",
            word = "Please",
            pronunciationMalayalam = "പ്ലീസ്",
            malayalamMeaning = "ദയവായി",
            exampleEnglish = "Please give me some water.",
            exampleMalayalam = "ദയവായി എനിക്ക് കുറച്ച് വെള്ളം തരൂ."
        ),
        Vocabulary(
            id = "v3",
            word = "Thank you",
            pronunciationMalayalam = "ഥാങ്ക് യു",
            malayalamMeaning = "നന്ദി",
            exampleEnglish = "Thank you for your help.",
            exampleMalayalam = "നിങ്ങളുടെ സഹായത്തിന് നന്ദി."
        ),
        Vocabulary(
            id = "v4",
            word = "Sorry",
            pronunciationMalayalam = "സോറി",
            malayalamMeaning = "ക്ഷമിക്കുക / ഖേദിക്കുന്നു",
            exampleEnglish = "I am sorry for being late.",
            exampleMalayalam = "വൈകിയതിൽ ഞാൻ ക്ഷമ ചോദിക്കുന്നു."
        ),
        Vocabulary(
            id = "v5",
            word = "Water",
            pronunciationMalayalam = "വാട്ടർ",
            malayalamMeaning = "വെള്ളം",
            exampleEnglish = "I want to drink water.",
            exampleMalayalam = "എനിക്ക് വെള്ളം കുടിക്കണം."
        ),
        Vocabulary(
            id = "v6",
            word = "Food",
            pronunciationMalayalam = "ഫുഡ്",
            malayalamMeaning = "ഭക്ഷണം",
            exampleEnglish = "This food is very tasty.",
            exampleMalayalam = "ഈ ഭക്ഷണം വളരെ രുചികരമാണ്."
        ),
        Vocabulary(
            id = "v7",
            word = "Friend",
            pronunciationMalayalam = "ഫ്രണ്ട്",
            malayalamMeaning = "സുഹൃത്ത്",
            exampleEnglish = "She is my best friend.",
            exampleMalayalam = "അവൾ എന്റെ ഏറ്റവും നല്ല സുഹൃത്താണ്."
        ),
        Vocabulary(
            id = "v8",
            word = "Understand",
            pronunciationMalayalam = "അണ്ടർസ്റ്റാൻഡ്",
            malayalamMeaning = "മനസ്സിലാക്കുക",
            exampleEnglish = "Do you understand the lesson?",
            exampleMalayalam = "നിങ്ങൾക്ക് പാഠം മനസ്സിലായോ?"
        ),
        Vocabulary(
            id = "v9",
            word = "Beautiful",
            pronunciationMalayalam = "ബ്യൂട്ടിഫുൾ",
            malayalamMeaning = "മനോഹരമായ",
            exampleEnglish = "Kerala is a beautiful place.",
            exampleMalayalam = "കേരളം ഒരു മനോഹരമായ സ്ഥലമാണ്."
        ),
        Vocabulary(
            id = "v10",
            word = "Happy",
            pronunciationMalayalam = "ഹാപ്പി",
            malayalamMeaning = "സന്തോഷമുള്ള",
            exampleEnglish = "I am very happy today.",
            exampleMalayalam = "ഞാൻ ഇന്ന് വളരെ സന്തോഷവാനാണ്."
        )
    )

    val quizzes = listOf(
        Quiz(
            id = "q1_basics",
            title = "Basics of English",
            malayalamTitle = "ലളിതമായ ഇംഗ്ലീഷ് ചോദ്യങ്ങൾ",
            category = "Grammar",
            questions = listOf(
                Question(
                    id = "q1_q1",
                    questionText = "Complete the greeting: 'Hello, how _____ you?'",
                    options = listOf("am", "is", "are", "be"),
                    correctOptionIndex = 2,
                    explanationMalayalam = "'You' എന്ന വാക്കിനൊപ്പം എപ്പോഴും 'are' ആണ് ഉപയോഗിക്കുക (how are you)."
                ),
                Question(
                    id = "q1_q2",
                    questionText = "Which pronoun means 'ഞാൻ' in English?",
                    options = listOf("You", "He", "She", "I"),
                    correctOptionIndex = 3,
                    explanationMalayalam = "'I' എന്നാൽ 'ഞാൻ' എന്നാണ് അർത്ഥം."
                ),
                Question(
                    id = "q1_q3",
                    questionText = "Which of the following is used to introduce your name?",
                    options = listOf("My name is...", "I name is...", "Mine name is...", "Me name is..."),
                    correctOptionIndex = 0,
                    explanationMalayalam = "പേര് പരിചയപ്പെടുത്താൻ 'My name is [name]' എന്ന് പറയണം."
                )
            )
        ),
        Quiz(
            id = "q2_to_be",
            title = "Am, Is, Are Quiz",
            malayalamTitle = "Am, Is, Are പരീക്ഷണം",
            category = "Grammar",
            questions = listOf(
                Question(
                    id = "q2_q1",
                    questionText = "I _____ a good student.",
                    options = listOf("is", "am", "are", "be"),
                    correctOptionIndex = 1,
                    explanationMalayalam = "'I' എന്ന വാക്കിനൊപ്പം എപ്പോഴും 'am' മാത്രമേ ഉപയോഗിക്കൂ."
                ),
                Question(
                    id = "q2_q2",
                    questionText = "He _____ my English teacher.",
                    options = listOf("is", "am", "are", "was"),
                    correctOptionIndex = 0,
                    explanationMalayalam = "ഏകവചനമായ 'He' എന്ന വാക്കിനൊപ്പം 'is' ആണ് അനുയോജ്യം."
                ),
                Question(
                    id = "q2_q3",
                    questionText = "We _____ learning English together.",
                    options = listOf("am", "is", "are", "be"),
                    correctOptionIndex = 2,
                    explanationMalayalam = "ബഹുവചനമായ 'We' എന്നതിനൊപ്പം എപ്പോഴും 'are' ഉപയോഗിക്കുന്നു."
                )
            )
        ),
        Quiz(
            id = "q3_vocab",
            title = "Vocabulary Test",
            malayalamTitle = "പദസമ്പത്ത് പരിശോധന",
            category = "Vocabulary",
            questions = listOf(
                Question(
                    id = "q3_q1",
                    questionText = "What is the Malayalam meaning of the word 'Please'?",
                    options = listOf("നന്ദി", "ദയവായി", "ക്ഷമിക്കുക", "ഹലോ"),
                    correctOptionIndex = 1,
                    explanationMalayalam = "'Please' എന്നാൽ 'ദയവായി' എന്നാണ് അർത്ഥം."
                ),
                Question(
                    id = "q3_q2",
                    questionText = "English word for 'വെള്ളം' is:",
                    options = listOf("Food", "Milk", "Tea", "Water"),
                    correctOptionIndex = 3,
                    explanationMalayalam = "'Water' എന്നാൽ 'വെള്ളം' ആണ്."
                ),
                Question(
                    id = "q3_q3",
                    questionText = "Choose the correct English word for 'മനസ്സിലാക്കുക':",
                    options = listOf("Understand", "Speak", "Listen", "Read"),
                    correctOptionIndex = 0,
                    explanationMalayalam = "'Understand' എന്നാൽ 'മനസ്സിലാക്കുക' എന്നാണ് അർത്ഥം."
                )
            )
        )
    )

    val pronunciationSentences = listOf(
        "Hello, how are you today?",
        "My name is Arun and I am learning English.",
        "Could you please give me some water?",
        "Kerala is a very beautiful place.",
        "Thank you so much for your kind help.",
        "I understand this grammar lesson clearly."
    )
}
