package com.example.data.repository

import com.example.data.local.LessonProgressDao
import com.example.data.local.VocabProgressDao
import com.example.data.local.QuizScoreDao
import com.example.data.local.UserStatsDao
import com.example.data.model.LessonProgress
import com.example.data.model.VocabProgress
import com.example.data.model.QuizScore
import com.example.data.model.UserStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AppRepository(
    private val lessonDao: LessonProgressDao,
    private val vocabDao: VocabProgressDao,
    private val quizDao: QuizScoreDao,
    private val statsDao: UserStatsDao
) {
    val allLessonProgress: Flow<List<LessonProgress>> = lessonDao.getAllProgress()
    val allVocabProgress: Flow<List<VocabProgress>> = vocabDao.getAllProgress()
    val allQuizScores: Flow<List<QuizScore>> = quizDao.getAllScores()
    val userStats: Flow<UserStats?> = statsDao.getStats()

    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Calendar.getInstance().time)
    }

    private fun getYesterdayDateString(): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DATE, -1)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(cal.time)
    }

    suspend fun getOrCreateStats(): UserStats {
        val existing = statsDao.getStatsDirect()
        if (existing != null) {
            return existing
        }
        val newStats = UserStats(
            id = 1,
            totalXp = 0,
            currentStreak = 0,
            lastActiveDate = "",
            lessonsCompletedCount = 0,
            wordsMasteredCount = 0,
            lastChallengeDate = ""
        )
        statsDao.insertStats(newStats)
        return newStats
    }

    suspend fun updateStreakAndActivity() {
        val stats = getOrCreateStats()
        val today = getTodayDateString()
        val yesterday = getYesterdayDateString()

        if (stats.lastActiveDate == today) {
            // Already active today, streak remains same
            return
        }

        val newStreak = if (stats.lastActiveDate == yesterday) {
            stats.currentStreak + 1
        } else if (stats.lastActiveDate.isEmpty()) {
            1
        } else {
            // Streak broken, reset to 1
            1
        }

        statsDao.insertStats(
            stats.copy(
                lastActiveDate = today,
                currentStreak = newStreak,
                totalXp = stats.totalXp + 10 // 10 XP bonus for logging in / active day!
            )
        )
    }

    suspend fun completeLesson(lessonId: String) {
        val existing = lessonDao.getProgressForLesson(lessonId)
        if (existing == null || !existing.isCompleted) {
            lessonDao.insertProgress(LessonProgress(lessonId, true))
            
            // Update Stats
            val stats = getOrCreateStats()
            val completedList = lessonDao.getAllProgress().firstOrNull() ?: emptyList()
            val completedCount = completedList.count { it.isCompleted }
            
            statsDao.insertStats(
                stats.copy(
                    totalXp = stats.totalXp + 50, // 50 XP per lesson!
                    lessonsCompletedCount = completedCount
                )
            )
        }
    }

    suspend fun practiceVocab(vocabId: String, markAsMastered: Boolean) {
        val existing = vocabDao.getProgressForVocab(vocabId)
        val isAlreadyMastered = existing?.isMastered ?: false
        val times = (existing?.timesPracticed ?: 0) + 1
        
        vocabDao.insertProgress(
            VocabProgress(
                vocabId = vocabId,
                isMastered = markAsMastered || isAlreadyMastered,
                timesPracticed = times
            )
        )

        if (markAsMastered && !isAlreadyMastered) {
            val stats = getOrCreateStats()
            val masteredList = vocabDao.getAllProgress().firstOrNull() ?: emptyList()
            val masteredCount = masteredList.count { it.isMastered }

            statsDao.insertStats(
                stats.copy(
                    totalXp = stats.totalXp + 20, // 20 XP per mastered word!
                    wordsMasteredCount = masteredCount
                )
            )
        }
    }

    suspend fun saveQuizScore(quizId: String, score: Int, total: Int) {
        val existing = quizDao.getScoreForQuiz(quizId)
        val previousHigh = existing?.highScore ?: 0
        
        if (score > previousHigh) {
            quizDao.insertScore(QuizScore(quizId, score, total))
            
            val stats = getOrCreateStats()
            val xpGain = (score - previousHigh) * 15 // 15 XP per net new correct answer!
            statsDao.insertStats(
                stats.copy(
                    totalXp = stats.totalXp + xpGain
                )
            )
        } else {
            // Re-practice gives small bonus
            val stats = getOrCreateStats()
            statsDao.insertStats(
                stats.copy(
                    totalXp = stats.totalXp + 5 // 5 XP participation!
                )
            )
        }
    }

    suspend fun completeDailyChallenge() {
        val today = getTodayDateString()
        val stats = getOrCreateStats()
        if (stats.lastChallengeDate != today) {
            statsDao.insertStats(
                stats.copy(
                    lastChallengeDate = today,
                    totalXp = stats.totalXp + 100 // 100 XP Daily Challenge bonus!
                )
            )
        }
    }

    suspend fun earnPronunciationXp() {
        val stats = getOrCreateStats()
        statsDao.insertStats(
            stats.copy(
                totalXp = stats.totalXp + 30 // 30 XP for a successful pronunciation match!
            )
        )
    }
}
