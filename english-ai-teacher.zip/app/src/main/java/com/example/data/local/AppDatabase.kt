package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.LessonProgress
import com.example.data.model.VocabProgress
import com.example.data.model.QuizScore
import com.example.data.model.UserStats
import kotlinx.coroutines.flow.Flow

// --- DAOs ---

@Dao
interface LessonProgressDao {
    @Query("SELECT * FROM lesson_progress")
    fun getAllProgress(): Flow<List<LessonProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: LessonProgress)

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId LIMIT 1")
    suspend fun getProgressForLesson(lessonId: String): LessonProgress?
}

@Dao
interface VocabProgressDao {
    @Query("SELECT * FROM vocab_progress")
    fun getAllProgress(): Flow<List<VocabProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: VocabProgress)

    @Query("SELECT * FROM vocab_progress WHERE vocabId = :vocabId LIMIT 1")
    suspend fun getProgressForVocab(vocabId: String): VocabProgress?
}

@Dao
interface QuizScoreDao {
    @Query("SELECT * FROM quiz_score")
    fun getAllScores(): Flow<List<QuizScore>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScore(score: QuizScore)

    @Query("SELECT * FROM quiz_score WHERE quizId = :quizId LIMIT 1")
    suspend fun getScoreForQuiz(quizId: String): QuizScore?
}

@Dao
interface UserStatsDao {
    @Query("SELECT * FROM user_stats WHERE id = 1 LIMIT 1")
    fun getStats(): Flow<UserStats?>

    @Query("SELECT * FROM user_stats WHERE id = 1 LIMIT 1")
    suspend fun getStatsDirect(): UserStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStats(stats: UserStats)
}

// --- AppDatabase ---

@Database(
    entities = [
        LessonProgress::class,
        VocabProgress::class,
        QuizScore::class,
        UserStats::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lessonProgressDao(): LessonProgressDao
    abstract fun vocabProgressDao(): VocabProgressDao
    abstract fun quizScoreDao(): QuizScoreDao
    abstract fun userStatsDao(): UserStatsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "english_ai_teacher_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
